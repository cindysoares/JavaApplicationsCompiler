package helloworld;

public class HelloWorld {

	public static void main(String[] args) {
		System.out.println(new HelloWorld().sayHello());
	}
	
	protected String sayHello() {
		return "Hello World!";
	}
	
}
