package helloworld;

import org.junit.Assert;
import org.junit.Test;

public class HelloWorldTest {

	HelloWorld helloWorld = new HelloWorld();
	
	@Test
	public void testHelloWorld() {
		Assert.assertEquals("Hello World!", helloWorld.sayHello());
	}
	
}
